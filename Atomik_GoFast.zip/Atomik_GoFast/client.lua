local showUI = false
local markerPositions = {
    vector3(771.37, -3063.51, 14.73)  
}

local currentMission = {
    vehicle = nil,
    vehicleBlip = nil,
    destinationBlip = nil,
    zone = nil,
    markerActive = false
}

function DebugPrint(msg)
    print("[GOFAST DEBUG] "..msg)
end

function CleanupMission()
    if currentMission.vehicle and DoesEntityExist(currentMission.vehicle) then
        DeleteVehicle(currentMission.vehicle)
    end

    if currentMission.vehicleBlip then
        RemoveBlip(currentMission.vehicleBlip)
    end
    if currentMission.destinationBlip then
        RemoveBlip(currentMission.destinationBlip)
    end

    if currentMission.zone then
        if type(currentMission.zone.destroy) == 'function' then
            currentMission.zone:destroy()
        elseif type(currentMission.zone.remove) == 'function' then
            currentMission.zone:remove()
        end
    end

    currentMission.markerActive = false

    DebugPrint("Mission nettoyée")
end

function CreateMissionMarkerThread(destination)
    Citizen.CreateThread(function()
        while currentMission.markerActive do
            DrawMarker(
                1,  
                destination.x, destination.y, destination.z - 1.0,
                0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                3.0, 3.0, 3.0,
                0, 255, 0, 150,
                false, true, 2, false
            )
            Citizen.Wait(0)
        end
        DebugPrint("Marker désactivé")
    end)
end

function CreateMission(missionType)
    CleanupMission()
    local cfg = Config.Missions[missionType]
    if not cfg then return end
    TriggerServerEvent('gofast:alertPolice', missionType, cfg.vehicle)
    local spawnPoint = cfg.spawnPoints[math.random(#cfg.spawnPoints)]

    local model = GetHashKey(cfg.vehicle)
    RequestModel(model)
    while not HasModelLoaded(model) do 
        Citizen.Wait(10) 
    end

    currentMission.vehicle = CreateVehicle(
        model, 
        spawnPoint.x, 
        spawnPoint.y, 
        spawnPoint.z, 
        GetEntityHeading(PlayerPedId()), 
        true, 
        false
    )
    SetVehicleOnGroundProperly(currentMission.vehicle)
    SetVehicleNumberPlateText(currentMission.vehicle, "GOFAST"..math.random(100,999))
    SetVehicleEngineOn(currentMission.vehicle, true, true, false)

    TaskWarpPedIntoVehicle(PlayerPedId(), currentMission.vehicle, -1)
    SetVehicleNumberPlateText(vehicle, "gofast")
    currentMission.vehicleBlip = AddBlipForEntity(currentMission.vehicle)
    SetBlipSprite(currentMission.vehicleBlip, cfg.blipSettings.sprite)
    SetBlipColour(currentMission.vehicleBlip, cfg.blipSettings.color)
    SetBlipScale(currentMission.vehicleBlip, cfg.blipSettings.scale)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(cfg.blipSettings.label)
    EndTextCommandSetBlipName(currentMission.vehicleBlip)

    currentMission.destinationBlip = AddBlipForCoord(cfg.destination.x, cfg.destination.y, cfg.destination.z)
    SetBlipSprite(currentMission.destinationBlip, 1)
    SetBlipColour(currentMission.destinationBlip, 5)
    SetBlipScale(currentMission.destinationBlip, 1.0)
    SetBlipRoute(currentMission.destinationBlip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Destination de mission")
    EndTextCommandSetBlipName(currentMission.destinationBlip)

    currentMission.zone = lib.zones.sphere({
        coords = cfg.destination,
        radius = cfg.targetRadius,
        onEnter = function()
            if IsPedInVehicle(PlayerPedId(), currentMission.vehicle, false) then
                TriggerServerEvent('gofast:missionComplete', {
                    type = missionType,
                    reward = cfg.reward
                })
                CleanupMission()
                lib.notify({
                    title = 'Mission Terminée',
                    description = ('Vous avez gagné $%s'):format(cfg.reward),
                    type = 'success'
                })
            else
                lib.notify({
                    title = 'Information',
                    description = 'Vous devez être dans le véhicule de mission',
                    type = 'inform'
                })
            end
        end
    })

    currentMission.markerActive = true
    CreateMissionMarkerThread(cfg.destination)
end

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        
        if showUI then
            DisableControlAction(0, 1, true)  
            DisableControlAction(0, 2, true)  
            
            if IsDisabledControlJustReleased(0, 322) then  
                showUI = false
                SetNuiFocus(false, false)
                SendNUIMessage({
                    type = "close", 
                    show = false
                })
            end
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local playerCoords = GetEntityCoords(PlayerPedId())
        local inMarker = false

        for _, pos in ipairs(markerPositions) do
            local distance = #(playerCoords - pos)
            if distance < 15.0 then
                inMarker = true
                DrawMarker(1, pos.x, pos.y, pos.z - 1.0, 0, 0, 0, 0, 0, 0, 2.0, 2.0, 1.0, 255, 165, 0, 150)
                
                if IsControlJustReleased(0, 38) then  
                    showUI = true
                    SetNuiFocus(true, true)
                    SendNUIMessage({
                        type = "toggle",
                        show = true
                    })
                end
            end
        end

        if not inMarker and showUI then
            showUI = false
            SetNuiFocus(false, false)
            SendNUIMessage({
                type = "toggle",
                show = false
            })
        end
    end
end)

RegisterNUICallback('close', function(data, cb)
    showUI = false
    SetNuiFocus(false, false)
    cb({})
end)

RegisterNUICallback('startMission', function(data, cb)
    CreateMission(data.difficulty)
    cb({})
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        CleanupMission()
    end
    DebugPrint("Resource "..resourceName.." is stopping. Mission cleaned up.")
end)




RegisterNetEvent('gofast:policeAlert')
AddEventHandler('gofast:policeAlert', function(missionType, vehicleModel)
    if lib then  
        lib.notify({
            title = 'ALERTE GOFAST',
            description = ('Un véhicule suspect (%s) a été signalé !'):format(vehicleModel),
            type = 'error',
            position = 'top',
            duration = 10000  
        })
    else  -- Fallback basique
        BeginTextCommandThefeedPost('STRING')
        AddTextComponentSubstringPlayerName(('ALERTE: Course illégale en cours (%s - %s)'):format(missionType, vehicleModel))
        EndTextCommandThefeedPostTicker(true, true)
    end

    local blip = AddBlipForRadius(markerPositions[1].x, markerPositions[1].y, markerPositions[1].z, 150.0)
    SetBlipColour(blip, 1) 
    SetBlipAlpha(blip, 80) 
    SetBlipDisplay(blip, 8)  
    Citizen.SetTimeout(30000, function() RemoveBlip(blip) end)  
end)