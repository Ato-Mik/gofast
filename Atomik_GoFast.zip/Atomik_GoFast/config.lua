Config = {
    Missions = {
        simple = {
            vehicle = 'rebla',
            spawnPoints = { 
                vector3(1257.19, -3153.15, 5.80),
               
            },
            destination = vector3(-90.50, -2089.68, 17.43),
            blipSettings = {
                sprite = 1,
                color = 5,
                scale = 1.0,
                label = "Mission Simple"
            },
            reward = 3000,
            targetRadius = 3.0
        },

        moyenne = {
            vehicle = 'astron',
            spawnPoints = {
                vector3(1257.19, -3153.15, 5.80),
                
            },
            destination = vector3(1117.05, 55.10, 80.76),
            blipSettings = {
                sprite = 1,
                color = 17, 
                scale = 1.2,
                label = "Mission Moyenne" 
            },
            reward = 6000,
            targetRadius = 3.0
        },

        difficile = {
            vehicle = 'baller2',
            spawnPoints = {
                vector3(1257.19, -3153.15, 5.80),

            },
            destination = vector3(1361.04, 3619.18, 34.89),
            blipSettings = {
                sprite = 1,
                color = 1,
                scale = 1.5,
                label = "Mission Difficile"
            },
            reward = 9000,
            targetRadius = 3.0
        }
    }
}