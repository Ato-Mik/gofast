ESX = exports["es_extended"]:getSharedObject()
RegisterServerEvent('gofast:missionComplete')
AddEventHandler('gofast:missionComplete', function(data)
    local src = source
    local reward = data.reward
    
    if not reward or reward <= 0 then return end

    exports.ox_inventory:AddItem(
        src,           
        'money',       
        reward,        
        nil,           
        nil,           
        function(success)
            if success then
                print(('[gofast] Joueur %s a reçu $%s'):format(GetPlayerName(src), reward))
                TriggerClientEvent('ox_lib:notify', src, {
                    title = 'Mission Complète',
                    description = ('Vous avez reçu $%s'):format(reward),
                    type = 'success',
                    duration = 5000
                })
            else
                print(('[gofast] Erreur en donnant $%s au joueur %s'):format(reward, GetPlayerName(src)))
                TriggerClientEvent('ox_lib:notify', src, {
                    title = 'Erreur',
                    description = 'Échec du paiement',
                    type = 'error',
                    duration = 5000
                })
            end
        end
    )
end)


RegisterServerEvent('gofast:alertPolice')
AddEventHandler('gofast:alertPolice', function(missionType, vehicleModel)
    local players = GetPlayers()
    
    for _, playerId in ipairs(players) do
        local xPlayer = ESX.GetPlayerFromId(playerId) 
        
        if xPlayer and xPlayer.job.name == 'police' then 
            TriggerClientEvent('gofast:policeAlert', playerId, missionType, vehicleModel)
        end
    end
end)