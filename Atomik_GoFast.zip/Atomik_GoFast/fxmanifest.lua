fx_version 'cerulean'
game 'gta5'
lua54 'yes'
ui_page 'dist/index.html'

files {
    'dist/index.html',
    'dist/styles.css',
    'dist/img/*.png',
    'dist/img/*.jpg'
}

client_scripts {
    'client.lua',
    'config.lua',
}

server_scripts {
    'server.lua',
    'config.lua',

}

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}

escrow_ignore {
    'config.lua'
}